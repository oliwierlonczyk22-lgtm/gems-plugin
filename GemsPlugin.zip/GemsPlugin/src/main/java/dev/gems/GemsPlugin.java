package dev.gems;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.*;
import org.bukkit.attribute.Attribute;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabExecutor;
import org.bukkit.entity.*;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.entity.EntityDeathEvent;
import org.bukkit.event.entity.EntityExplodeEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.player.*;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.util.RayTraceResult;
import org.bukkit.util.Vector;

import java.util.*;

public class GemsPlugin extends JavaPlugin implements Listener, TabExecutor {

    private NamespacedKey gemKey;
    private NamespacedKey equippedKey;
    private NamespacedKey projKey;
    private final Map<UUID, Long> cooldowns = new HashMap<>();
    private final Random random = new Random();
    private double dropChance;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        dropChance = getConfig().getDouble("drop-chance", 0.05);
        gemKey = new NamespacedKey(this, "gem");
        equippedKey = new NamespacedKey(this, "equipped");
        projKey = new NamespacedKey(this, "gemproj");

        Bukkit.getPluginManager().registerEvents(this, this);
        var cmd = getCommand("gem");
        if (cmd != null) {
            cmd.setExecutor(this);
            cmd.setTabCompleter(this);
        }
        for (Player p : Bukkit.getOnlinePlayers()) updateFlight(p);
    }

    @Override
    public void onDisable() {
        for (Player p : Bukkit.getOnlinePlayers()) {
            GameMode gm = p.getGameMode();
            if (gm == GameMode.SURVIVAL || gm == GameMode.ADVENTURE) {
                p.setAllowFlight(false);
                p.setFlying(false);
            }
        }
    }

    // ------------------------------------------------------------ items

    public ItemStack createGem(Ability a) {
        ItemStack it = new ItemStack(a.material);
        ItemMeta m = it.getItemMeta();
        m.displayName(Component.text("Kryształ: " + a.displayName, a.color)
                .decoration(TextDecoration.ITALIC, false));
        m.lore(List.of(
                Component.text(a.description, NamedTextColor.GRAY).decoration(TextDecoration.ITALIC, false),
                Component.empty(),
                Component.text("PPM - załóż kryształ", NamedTextColor.YELLOW).decoration(TextDecoration.ITALIC, false),
                Component.text("Podwójna spacja - użyj", NamedTextColor.YELLOW).decoration(TextDecoration.ITALIC, false),
                Component.text("Cooldown: " + a.cooldown + "s", NamedTextColor.DARK_GRAY).decoration(TextDecoration.ITALIC, false)
        ));
        m.setEnchantmentGlintOverride(true);
        m.getPersistentDataContainer().set(gemKey, PersistentDataType.STRING, a.name());
        it.setItemMeta(m);
        return it;
    }

    private Ability abilityOf(ItemStack item) {
        if (item == null || !item.hasItemMeta()) return null;
        String s = item.getItemMeta().getPersistentDataContainer().get(gemKey, PersistentDataType.STRING);
        return parse(s);
    }

    private Ability parse(String s) {
        if (s == null) return null;
        try {
            return Ability.valueOf(s.toUpperCase(Locale.ROOT));
        } catch (IllegalArgumentException ex) {
            return null;
        }
    }

    private Ability getEquipped(Player p) {
        return parse(p.getPersistentDataContainer().get(equippedKey, PersistentDataType.STRING));
    }

    private void setEquipped(Player p, Ability a) {
        if (a == null) p.getPersistentDataContainer().remove(equippedKey);
        else p.getPersistentDataContainer().set(equippedKey, PersistentDataType.STRING, a.name());
        updateFlight(p);
    }

    private void giveItem(Player p, ItemStack item) {
        for (ItemStack left : p.getInventory().addItem(item).values()) {
            p.getWorld().dropItemNaturally(p.getLocation(), left);
        }
    }

    // Double space = toggle flight, so allowFlight must be on while a gem is equipped.
    private void updateFlight(Player p) {
        GameMode gm = p.getGameMode();
        if (gm != GameMode.SURVIVAL && gm != GameMode.ADVENTURE) return;
        boolean has = getEquipped(p) != null;
        p.setAllowFlight(has);
        if (!has) p.setFlying(false);
    }

    // ------------------------------------------------------------ events

    @EventHandler
    public void onMobDeath(EntityDeathEvent e) {
        LivingEntity mob = e.getEntity();
        if (mob instanceof Player || mob instanceof ArmorStand) return;
        if (mob.getKiller() == null) return;
        if (random.nextDouble() >= dropChance) return;
        Ability a = Ability.values()[random.nextInt(Ability.values().length)];
        e.getDrops().add(createGem(a));
    }

    @EventHandler
    public void onInteract(PlayerInteractEvent e) {
        if (e.getHand() != EquipmentSlot.HAND) return;
        if (e.getAction() != Action.RIGHT_CLICK_AIR && e.getAction() != Action.RIGHT_CLICK_BLOCK) return;
        Player p = e.getPlayer();
        ItemStack hand = p.getInventory().getItemInMainHand();
        Ability a = abilityOf(hand);
        if (a == null) return;
        e.setCancelled(true);

        Ability old = getEquipped(p);
        if (old == a) {
            p.sendActionBar(Component.text("Ten kryształ jest już założony.", NamedTextColor.RED));
            return;
        }
        if (hand.getAmount() > 1) hand.setAmount(hand.getAmount() - 1);
        else p.getInventory().setItemInMainHand(null);

        if (old != null) giveItem(p, createGem(old)); // limit: 1 założony kryształ
        setEquipped(p, a);
        p.playSound(p.getLocation(), Sound.ITEM_ARMOR_EQUIP_DIAMOND, 1f, 1.2f);
        p.sendActionBar(Component.text("Założono: " + a.displayName + " - użyj podwójną spacją", a.color));
    }

    @EventHandler
    public void onToggleFlight(PlayerToggleFlightEvent e) {
        Player p = e.getPlayer();
        GameMode gm = p.getGameMode();
        if (gm == GameMode.CREATIVE || gm == GameMode.SPECTATOR) return;
        if (!e.isFlying()) return;
        Ability a = getEquipped(p);
        if (a == null) return;
        e.setCancelled(true);
        p.setFlying(false);
        tryUse(p, a);
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent e) {
        updateFlight(e.getPlayer());
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        Player p = e.getPlayer();
        GameMode gm = p.getGameMode();
        if (gm == GameMode.SURVIVAL || gm == GameMode.ADVENTURE) {
            p.setAllowFlight(false);
            p.setFlying(false);
        }
    }

    @EventHandler
    public void onRespawn(PlayerRespawnEvent e) {
        Player p = e.getPlayer();
        Bukkit.getScheduler().runTask(this, () -> updateFlight(p));
    }

    @EventHandler
    public void onGameMode(PlayerGameModeChangeEvent e) {
        Player p = e.getPlayer();
        Bukkit.getScheduler().runTask(this, () -> updateFlight(p));
    }

    @EventHandler
    public void onExplode(EntityExplodeEvent e) {
        if (e.getEntity().getPersistentDataContainer().has(projKey, PersistentDataType.BYTE)) {
            e.blockList().clear();
        }
    }

    // ------------------------------------------------------------ menu

    private static class MenuHolder implements InventoryHolder {
        private Inventory inv;

        @Override
        public Inventory getInventory() {
            return inv;
        }
    }

    private void openMenu(Player p) {
        MenuHolder holder = new MenuHolder();
        Inventory inv = Bukkit.createInventory(holder, 27, Component.text("Kryształy"));
        holder.inv = inv;
        int slot = 0;
        for (Ability a : Ability.values()) inv.setItem(slot++, createGem(a));
        p.openInventory(inv);
    }

    @EventHandler
    public void onMenuClick(InventoryClickEvent e) {
        if (!(e.getView().getTopInventory().getHolder() instanceof MenuHolder)) return;
        e.setCancelled(true);
        if (e.getClickedInventory() != e.getView().getTopInventory()) return;
        Ability a = abilityOf(e.getCurrentItem());
        if (a == null) return;
        if (e.getWhoClicked() instanceof Player p) {
            giveItem(p, createGem(a));
            p.playSound(p.getLocation(), Sound.ENTITY_ITEM_PICKUP, 1f, 1f);
        }
    }

    @EventHandler
    public void onMenuDrag(InventoryDragEvent e) {
        if (e.getView().getTopInventory().getHolder() instanceof MenuHolder) e.setCancelled(true);
    }

    // ------------------------------------------------------------ abilities

    private void tryUse(Player p, Ability a) {
        long now = System.currentTimeMillis();
        Long until = cooldowns.get(p.getUniqueId());
        if (until != null && until > now) {
            double left = (until - now) / 1000.0;
            p.sendActionBar(Component.text(String.format(Locale.US, "%s: cooldown %.1fs", a.displayName, left),
                    NamedTextColor.RED));
            return;
        }
        cooldowns.put(p.getUniqueId(), now + a.cooldown * 1000L);
        useAbility(p, a);
        p.sendActionBar(Component.text("Użyto: " + a.displayName, a.color));
    }

    private List<LivingEntity> nearbyLiving(Player p, double r) {
        List<LivingEntity> list = new ArrayList<>();
        for (Entity en : p.getNearbyEntities(r, r, r)) {
            if (en instanceof LivingEntity le && !(en instanceof ArmorStand)) list.add(le);
        }
        return list;
    }

    private void useAbility(Player p, Ability a) {
        World w = p.getWorld();
        Location loc = p.getLocation();
        Location eye = p.getEyeLocation();
        Vector dir = eye.getDirection().normalize();

        switch (a) {
            case DASH -> {
                Vector v = dir.clone().setY(0);
                if (v.lengthSquared() < 0.001) v = dir.clone();
                v = v.normalize().multiply(1.9).setY(0.2);
                p.setVelocity(v);
                w.spawnParticle(Particle.CLOUD, loc, 20, 0.3, 0.1, 0.3, 0.05);
                w.playSound(loc, Sound.ENTITY_BAT_TAKEOFF, 1f, 1.2f);
            }
            case DOUBLE_JUMP -> {
                Vector cur = p.getVelocity();
                p.setVelocity(new Vector(cur.getX() * 1.2, 0.95, cur.getZ() * 1.2));
                p.setFallDistance(0f);
                w.spawnParticle(Particle.CLOUD, loc, 20, 0.3, 0.05, 0.3, 0.05);
                w.playSound(loc, Sound.ENTITY_BAT_TAKEOFF, 1f, 1.6f);
            }
            case SONIC_BOOM -> {
                Set<UUID> hit = new HashSet<>();
                for (int i = 1; i <= 16; i++) {
                    Location pt = eye.clone().add(dir.clone().multiply(i));
                    w.spawnParticle(Particle.SONIC_BOOM, pt, 1, 0, 0, 0, 0);
                    for (Entity en : w.getNearbyEntities(pt, 1.2, 1.2, 1.2)) {
                        if (en instanceof LivingEntity le && !(en instanceof ArmorStand)
                                && !le.equals(p) && hit.add(le.getUniqueId())) {
                            le.damage(12, p);
                            le.setVelocity(le.getVelocity().add(dir.clone().multiply(1.2).setY(0.4)));
                        }
                    }
                }
                w.playSound(loc, Sound.ENTITY_WARDEN_SONIC_BOOM, 1f, 1f);
            }
            case PEARL -> {
                p.launchProjectile(EnderPearl.class);
                w.playSound(loc, Sound.ENTITY_ENDER_PEARL_THROW, 1f, 1f);
            }
            case FIREBALL -> {
                LargeFireball fb = p.launchProjectile(LargeFireball.class, dir.clone().multiply(1.2));
                fb.setIsIncendiary(false);
                fb.setYield(1.5f);
                fb.getPersistentDataContainer().set(projKey, PersistentDataType.BYTE, (byte) 1);
                w.playSound(loc, Sound.ENTITY_BLAZE_SHOOT, 1f, 1f);
            }
            case LIGHTNING -> {
                RayTraceResult r = w.rayTrace(eye, dir, 30, FluidCollisionMode.NEVER, true, 0.5,
                        en -> !en.equals(p) && en instanceof LivingEntity);
                Location target = r != null
                        ? r.getHitPosition().toLocation(w)
                        : eye.clone().add(dir.clone().multiply(20));
                w.strikeLightning(target);
            }
            case HEAL -> {
                double max = p.getAttribute(Attribute.MAX_HEALTH).getValue();
                p.setHealth(Math.min(max, p.getHealth() + 10));
                p.addPotionEffect(new PotionEffect(PotionEffectType.REGENERATION, 100, 1));
                w.spawnParticle(Particle.HEART, loc.clone().add(0, 1.2, 0), 10, 0.4, 0.4, 0.4, 0);
                w.playSound(loc, Sound.ENTITY_PLAYER_LEVELUP, 1f, 1.5f);
            }
            case SLAM -> {
                for (LivingEntity le : nearbyLiving(p, 5)) {
                    le.damage(8, p);
                    le.setVelocity(le.getVelocity().setY(0.9));
                }
                w.spawnParticle(Particle.EXPLOSION, loc, 3, 1.5, 0.1, 1.5, 0);
                w.spawnParticle(Particle.CLOUD, loc, 40, 2.5, 0.1, 2.5, 0.05);
                w.playSound(loc, Sound.ENTITY_PLAYER_ATTACK_KNOCKBACK, 1f, 0.6f);
            }
            case SPEED -> {
                p.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, 160, 2));
                w.playSound(loc, Sound.ENTITY_PLAYER_LEVELUP, 1f, 2f);
            }
            case BLINK -> {
                Vector h = dir.clone().setY(0);
                if (h.lengthSquared() < 0.001) h = new Vector(0, 0, 1);
                h.normalize();
                for (int d = 8; d >= 1; d--) {
                    Location dest = loc.clone().add(h.clone().multiply(d));
                    if (dest.getBlock().isPassable() && dest.clone().add(0, 1, 0).getBlock().isPassable()) {
                        w.spawnParticle(Particle.PORTAL, loc.clone().add(0, 1, 0), 40, 0.3, 0.6, 0.3, 0.5);
                        p.teleport(dest);
                        w.spawnParticle(Particle.PORTAL, dest.clone().add(0, 1, 0), 40, 0.3, 0.6, 0.3, 0.5);
                        w.playSound(dest, Sound.ENTITY_ENDERMAN_TELEPORT, 1f, 1f);
                        break;
                    }
                }
            }
            case FREEZE -> {
                for (LivingEntity le : nearbyLiving(p, 7)) {
                    le.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, 100, 3));
                    le.setFreezeTicks(240);
                    w.spawnParticle(Particle.SNOWFLAKE, le.getLocation().add(0, 1, 0), 20, 0.4, 0.6, 0.4, 0.02);
                }
                w.spawnParticle(Particle.SNOWFLAKE, loc.clone().add(0, 1, 0), 60, 3, 0.5, 3, 0.02);
                w.playSound(loc, Sound.BLOCK_GLASS_BREAK, 1f, 0.8f);
            }
            case WIND_CHARGE -> {
                p.launchProjectile(WindCharge.class);
            }
            case VORTEX -> {
                for (LivingEntity le : nearbyLiving(p, 8)) {
                    Vector pull = loc.toVector().subtract(le.getLocation().toVector());
                    if (pull.lengthSquared() < 0.1) continue;
                    le.setVelocity(pull.normalize().multiply(1.1).setY(0.3));
                    w.spawnParticle(Particle.PORTAL, le.getLocation().add(0, 1, 0), 15, 0.3, 0.5, 0.3, 0.3);
                }
                w.playSound(loc, Sound.ENTITY_ENDERMAN_TELEPORT, 1f, 0.5f);
            }
            case SHIELD -> {
                p.addPotionEffect(new PotionEffect(PotionEffectType.ABSORPTION, 200, 2));
                p.addPotionEffect(new PotionEffect(PotionEffectType.RESISTANCE, 100, 1));
                w.playSound(loc, Sound.ITEM_ARMOR_EQUIP_GOLD, 1f, 1f);
            }
            case INVISIBILITY -> {
                p.addPotionEffect(new PotionEffect(PotionEffectType.INVISIBILITY, 200, 0, false, false, true));
                w.spawnParticle(Particle.CLOUD, loc.clone().add(0, 1, 0), 30, 0.3, 0.6, 0.3, 0.05);
            }
        }
    }

    // ------------------------------------------------------------ commands

    @Override
    public boolean onCommand(CommandSender s, Command c, String label, String[] args) {
        if (args.length > 0 && args[0].equalsIgnoreCase("unequip")) {
            if (!(s instanceof Player p)) {
                s.sendMessage("Tylko dla graczy.");
                return true;
            }
            Ability a = getEquipped(p);
            if (a == null) {
                p.sendMessage(Component.text("Nie masz założonego kryształu.", NamedTextColor.RED));
                return true;
            }
            setEquipped(p, null);
            giveItem(p, createGem(a));
            p.sendMessage(Component.text("Zdjęto kryształ: " + a.displayName, NamedTextColor.YELLOW));
            return true;
        }

        if (!s.hasPermission("gems.admin")) {
            s.sendMessage(Component.text("Brak uprawnień.", NamedTextColor.RED));
            return true;
        }

        if (args.length == 0) {
            if (s instanceof Player p) openMenu(p);
            else s.sendMessage("Tylko dla graczy.");
            return true;
        }

        if (args[0].equalsIgnoreCase("reload")) {
            reloadConfig();
            dropChance = getConfig().getDouble("drop-chance", 0.05);
            s.sendMessage(Component.text("Przeładowano config.", NamedTextColor.GREEN));
            return true;
        }

        if (args[0].equalsIgnoreCase("give") && args.length >= 2) {
            Ability a = parse(args[1]);
            if (a == null) {
                s.sendMessage(Component.text("Nieznana umiejętność.", NamedTextColor.RED));
                return true;
            }
            Player target;
            if (args.length >= 3) target = Bukkit.getPlayerExact(args[2]);
            else target = s instanceof Player p ? p : null;
            if (target == null) {
                s.sendMessage(Component.text("Nie znaleziono gracza.", NamedTextColor.RED));
                return true;
            }
            giveItem(target, createGem(a));
            s.sendMessage(Component.text("Dano kryształ " + a.displayName + " graczowi " + target.getName(),
                    NamedTextColor.GREEN));
            return true;
        }

        s.sendMessage(Component.text("/gem | /gem give <ability> [gracz] | /gem unequip | /gem reload",
                NamedTextColor.GRAY));
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender s, Command c, String label, String[] args) {
        List<String> out = new ArrayList<>();
        if (args.length == 1) {
            out.add("unequip");
            if (s.hasPermission("gems.admin")) out.addAll(List.of("give", "reload"));
        } else if (args.length == 2 && args[0].equalsIgnoreCase("give") && s.hasPermission("gems.admin")) {
            for (Ability a : Ability.values()) out.add(a.name().toLowerCase(Locale.ROOT));
        } else if (args.length == 3 && args[0].equalsIgnoreCase("give") && s.hasPermission("gems.admin")) {
            for (Player p : Bukkit.getOnlinePlayers()) out.add(p.getName());
        }
        String last = args[args.length - 1].toLowerCase(Locale.ROOT);
        out.removeIf(x -> !x.toLowerCase(Locale.ROOT).startsWith(last));
        return out;
    }
}
