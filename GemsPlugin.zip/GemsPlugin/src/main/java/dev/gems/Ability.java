package dev.gems;

import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Material;

public enum Ability {
    DASH("Dash", NamedTextColor.AQUA, Material.DIAMOND, 5, "Szybki zryw do przodu."),
    DOUBLE_JUMP("Podwójny skok", NamedTextColor.WHITE, Material.QUARTZ, 3, "Wybijasz się wysoko w powietrze."),
    SONIC_BOOM("Sonic Boom (Warden)", NamedTextColor.DARK_AQUA, Material.ECHO_SHARD, 12, "Fala dźwiękowa rani wszystko przed tobą."),
    PEARL("Perła Endermana", NamedTextColor.DARK_PURPLE, Material.AMETHYST_SHARD, 6, "Rzucasz perłę i się teleportujesz."),
    FIREBALL("Kula ognia", NamedTextColor.GOLD, Material.BLAZE_POWDER, 8, "Wystrzeliwujesz kulę ognia (bez niszczenia bloków)."),
    LIGHTNING("Piorun", NamedTextColor.YELLOW, Material.GLOWSTONE_DUST, 15, "Piorun uderza tam, gdzie patrzysz."),
    HEAL("Leczenie", NamedTextColor.RED, Material.GHAST_TEAR, 20, "Odnawia zdrowie i daje regenerację."),
    SLAM("Uderzenie w ziemię", NamedTextColor.GRAY, Material.IRON_NUGGET, 10, "Fala uderzeniowa wokół ciebie."),
    SPEED("Szybkość", NamedTextColor.GREEN, Material.EMERALD, 18, "Duży przyrost prędkości na kilka sekund."),
    BLINK("Teleport", NamedTextColor.LIGHT_PURPLE, Material.PRISMARINE_CRYSTALS, 6, "Natychmiastowy skok o kilka bloków do przodu."),
    FREEZE("Zamrożenie", NamedTextColor.BLUE, Material.LAPIS_LAZULI, 14, "Zamraża i spowalnia wrogów wokół ciebie."),
    WIND_CHARGE("Wind Charge", NamedTextColor.DARK_GREEN, Material.PRISMARINE_SHARD, 4, "Wystrzeliwujesz ładunek wiatru."),
    VORTEX("Wir", NamedTextColor.DARK_BLUE, Material.NAUTILUS_SHELL, 14, "Przyciąga pobliskich wrogów do ciebie."),
    SHIELD("Tarcza", NamedTextColor.GOLD, Material.GOLD_NUGGET, 25, "Absorpcja i odporność na krótki czas."),
    INVISIBILITY("Niewidzialność", NamedTextColor.DARK_GRAY, Material.COPPER_INGOT, 30, "Znikasz na kilka sekund.");

    public final String displayName;
    public final NamedTextColor color;
    public final Material material;
    public final int cooldown;
    public final String description;

    Ability(String displayName, NamedTextColor color, Material material, int cooldown, String description) {
        this.displayName = displayName;
        this.color = color;
        this.material = material;
        this.cooldown = cooldown;
        this.description = description;
    }
}
